/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;


/**
 *
 * @author HampusBolin
 */
@Entity
public class Question {
    @Id@GeneratedValue
    private int qId;
    
    private String title;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "category")
    private QuestionType category;  
    
    
    private int score;
    private int tId;

    public int getqId() {
        return qId;
    }

    public void setqId(int qId) {
        this.qId = qId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public QuestionType getCategory() {
        return category;
    }

    public void setCategory(QuestionType category) {
        this.category = category;
    }



    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public int gettId() {
        return tId;
    }

    public void settId(int tId) {
        this.tId = tId;
    }

   
    
}


  
   
