/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/**
 *
 * @author HampusBolin
 */
@Entity
public class Answer {
    @Id@GeneratedValue

    private int aId;
    private String title;
    private String ansStudent;
    private String ansTeacher;
    private int qId;

    public int getaId() {
        return aId;
    }

    public void setaId(int aId) {
        this.aId = aId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAnsStudent() {
        return ansStudent;
    }

    public void setAnsStudent(String ansStudent) {
        this.ansStudent = ansStudent;
    }

    public String getAnsTeacher() {
        return ansTeacher;
    }

    public void setAnsTeacher(String ansTeacher) {
        this.ansTeacher = ansTeacher;
    }

    public int getqId() {
        return qId;
    }

    public void setqId(int qId) {
        this.qId = qId;
    }
    
}
