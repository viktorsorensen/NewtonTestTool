package exercises.javafx.tableview;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.util.StringConverter;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.TableView;

public class BookSceneController implements Initializable{
	@FXML private TableView<Book> tblBook;
	@FXML private TableColumn<Book, Integer> colID, colQty;
	@FXML private TableColumn<Book, Double> colPrice;
	@FXML private TableColumn<Book, String> colTitle;
	@FXML private TextField txtID, txtTitle, txtQty, txtPrice;
	@FXML private Button btnAdd, btnSave, btnRemove;
	
	ObservableList<Book> lstBook;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		lstBook = FXCollections.observableArrayList(
				new Book(12345, "Java for Beginer", 10, 150),
				new Book(21316, "DotNet for Beginer", 10, 150),
				new Book(64453, "HTML Tuturial", 10, 150)
		);

		colID.setCellValueFactory( new PropertyValueFactory<Book, Integer>("id"));
		colTitle.setCellValueFactory( new PropertyValueFactory<Book, String>("title"));
		colQty.setCellValueFactory( new PropertyValueFactory<Book, Integer>("qty"));
		colPrice.setCellValueFactory( new PropertyValueFactory<Book, Double>("price"));
		
		tblBook.setItems(lstBook);
		tblBook.setEditable(true);
		
		// add event handle
		btnAdd.setOnAction((ActionEvent ev) -> {
			try {
				Book b = new Book(
						Integer.parseInt(txtID.getText()),
						txtTitle.getText(),
						Integer.parseInt(txtQty.getText()),
						Double.parseDouble(txtPrice.getText()));
				lstBook.add(b);
			} catch (NumberFormatException e) {
				System.out.println("Invalid data format ...");
			}	
		});

		// save event handle
		btnSave.setOnAction((ActionEvent ev) -> {
			Book selBook = lstBook.get( tblBook.getSelectionModel().getSelectedIndex() );
			try {
				selBook.setId(Integer.parseInt(txtID.getText()));
				selBook.setTitle(txtTitle.getText());
				selBook.setQty(Integer.parseInt(txtQty.getText()));
				selBook.setPrice(Double.parseDouble(txtPrice.getText()));		
			} catch (NumberFormatException e) {
				System.out.println("Invalid data format ...");
			}
		});
		
		// remove event handle
		btnRemove.setOnAction((ActionEvent ev) -> {
			Book selBook = (Book) tblBook.getSelectionModel().getSelectedItem();
			
			lstBook.remove(selBook);
			tblBook.getSelectionModel().clearSelection();
		});

		StringConverter<Integer> integerConverter = new StringConverter<Integer>() {

			@Override
			public String toString(Integer object) {
				return object.toString();
			}

			@Override
			public Integer fromString(String object) {
				return Integer.parseInt(object);	
			}
		};
		
		StringConverter<Double> doubleConverter = new StringConverter<Double>() {

			@Override
			public String toString(Double object) {
				return object.toString();
			}

			@Override
			public Double fromString(String object) {
				return Double.parseDouble(object);	
			}
		};
		
		// select row event handler
		tblBook.getSelectionModel().selectedItemProperty().addListener(
				(obsList, oldSelection, newSelection) -> {
					if (newSelection != null) {
						Book b = (Book) newSelection;
						txtID.setText(Integer.toString(b.getId()));
						txtTitle.setText(b.getTitle());
						txtQty.setText(Integer.toString(b.getQty()));
						txtPrice.setText(Double.toString(b.getPrice()));
					}
		});
		
//		colID.setEditable(false);
		colID.setCellFactory(TextFieldTableCell.forTableColumn(integerConverter));
		colID.setOnEditCommit(
				 (CellEditEvent<Book, Integer> cell) -> {
					 Book selBook = (Book) cell.getTableView().getItems().get( cell.getTablePosition().getRow() );
					 
					 selBook.setId(cell.getNewValue());
					 txtID.setText(cell.getNewValue().toString());
		});
		
		colTitle.setCellFactory(TextFieldTableCell.forTableColumn());
		colTitle.setOnEditCommit(
				 (CellEditEvent<Book, String> cell) -> {
					 Book selBook = (Book) cell.getTableView().getItems().get( cell.getTablePosition().getRow() );

					 selBook.setTitle(cell.getNewValue());
					 txtTitle.setText(cell.getNewValue());
		});
		
		colQty.setCellFactory(TextFieldTableCell.<Book, Integer>forTableColumn(integerConverter));
		colQty.setOnEditCommit(
				 (CellEditEvent<Book, Integer> cell) -> {
					 Book selBook = (Book) cell.getTableView().getItems().get( cell.getTablePosition().getRow() );
					 
					 selBook.setQty(cell.getNewValue());
					 txtQty.setText(cell.getNewValue().toString());
		});
		
		colPrice.setCellFactory(TextFieldTableCell.<Book, Double>forTableColumn(doubleConverter));
		colPrice.setOnEditCommit(
				 (CellEditEvent<Book, Double> cell) -> {
					 Book selBook = (Book) cell.getTableView().getItems().get( cell.getTablePosition().getRow() );
					 
					 selBook.setPrice(cell.getNewValue());
					 txtPrice.setText(cell.getNewValue().toString());
		});	}
}
