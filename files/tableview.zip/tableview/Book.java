package exercises.javafx.tableview;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;

public class Book {
    public SimpleIntegerProperty id;
    public SimpleStringProperty title;
    public SimpleIntegerProperty qty;
    public SimpleDoubleProperty price;
    
    public Book(int id, String title, int qty, double price) {
    	this.id = new SimpleIntegerProperty(id);
    	this.title = new SimpleStringProperty(title);
    	this.qty = new SimpleIntegerProperty(qty);
    	this.price = new SimpleDoubleProperty(price);
    }

    public Integer getId() {
		return id.get();
	}

	public String getTitle() {
        return title.get();
    }

    public Double getPrice() {
        return price.get();
    }

    public Integer getQty() {
        return qty.get();
    }

	public void setId(int id) {
		this.id.set(id);
	}

	public void setTitle(String name) {
		this.title.set(name);
	}

	public void setQty(int qty) {
		this.qty.set(qty);
	}

	public void setPrice(double price) {
		this.price.set(price);
	}
    
	// require by javafx for binding to a UI control
	public SimpleIntegerProperty idProperty() {
		return id;
	}
	
	// require by javafx for binding to a UI control
	public SimpleStringProperty titleProperty() {
		return title;
	}
	
	// require by javafx for binding to a UI control
	public SimpleIntegerProperty qtyProperty() {
		return qty;
	}
	
	// require by javafx for binding to a UI control
	public SimpleDoubleProperty priceProperty() {
		return price;
	}
}
